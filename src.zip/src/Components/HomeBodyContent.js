import React from 'react'

const HomeBodyContent = () => {
    return (
        <div>
            bodycontent goes here
        </div>
    )
}

export default HomeBodyContent
