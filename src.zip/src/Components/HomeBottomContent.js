import React from 'react'

const HomeBottomContent = () => {
    return (
        <div>
            Bottom content goes here
        </div>
    )
}

export default HomeBottomContent
