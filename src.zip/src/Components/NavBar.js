import React from 'react'

const NavBar = () => {
    return (
        <div>
            nav content goes here
        </div>
    )
}

export default NavBar
